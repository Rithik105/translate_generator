import 'dart:convert';
import 'package:universal_html/html.dart' as html;
import 'package:flutter/material.dart';
import 'package:translator/translator.dart';

class LanguageProvider with ChangeNotifier {
  bool _translating = false;
  static const List<Locale> _supportedLanguages = [
    Locale('en', 'us'),
    Locale('fr', 'fr'),
    Locale('hi', 'in'),
    Locale('ja', 'jp'),
    Locale('ar', 'sa'),
    Locale('es', 'es'),
    Locale('ko', 'kr'),
    Locale('pa', 'in'),
    Locale('pt', 'br'),
    Locale('ru', 'ru'),
    Locale('vi', 'vn'),
  ];
  Locale selectedLocale = const Locale('en');
  final Map<String, String> _languageData = {};
  final Map<String, String> _translatedData = {};
  double _progress = 0.0;

  bool get translating => _translating;
  set translating(bool value) {
    _translating = value;
    notifyListeners();
  }

  static List<Locale> get supportedLanguages => [..._supportedLanguages];
  Locale get selectedLanguage => selectedLocale;
  set setLocale(Locale locale) {
    selectedLocale = locale;
    notifyListeners();
  }

  Map<String, String> get languageData => _languageData;
  set languageData(Map<String, String> data) {
    _languageData.clear();
    _languageData.addAll(data);
    notifyListeners();
  }

  Map<String, String> get translatedData => _translatedData;
  set translatedData(Map<String, String> data) {
    _translatedData.clear();
    _translatedData.addAll(data);
    notifyListeners();
  }

  double get progress => _progress;
  set progress(double value) {
    _progress = value;
    notifyListeners();
  }

  void translate() async {
    progress = 0.0;
    translating = true;
    for (var entry in _languageData.entries) {
      Translation processedValue = await entry.value
          .translate(from: 'en', to: selectedLanguage.languageCode);
      _translatedData[entry.key] = processedValue.text;
      progress = _progress + 1;
    }
    translating = false;
  }

  void downloadFile() {
    downloadJsonFile(jsonEncode(translatedData));
  }

  void downloadJsonFile(String jsonString) {
    html.Blob blob = html.Blob([jsonString], 'application/json');
    html.AnchorElement(
      href: html.Url.createObjectUrlFromBlob(blob).toString(),
    ).setAttribute("download", "$selectedLanguage.json");
    html.AnchorElement(
      href: html.Url.createObjectUrlFromBlob(blob).toString(),
    ).click();
  }
}
