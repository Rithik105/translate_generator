import 'package:flutter/material.dart';

class UiProvider with ChangeNotifier {
  String? _fileName;
  bool _translating = false;
  double _progress = 0.0;
  double _totalLength = 0;

  String? get fileName {
    return _fileName;
  }

  set fileName(String? value) {
    _fileName = value;
    notifyListeners();
  }

  bool get translating {
    return _translating;
  }

  set translating(bool value) {
    _translating = value;
    notifyListeners();
  }

  double get progress {
    return _progress;
  }

  set progress(double value) {
    _progress = value;
    notifyListeners();
  }

  double get totalLength {
    return _totalLength;
  }

  set totalLength(double value) {
    _totalLength = value;
    notifyListeners();
  }
}
