import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:translate_generator/providers/language_provider.dart';
import 'package:translate_generator/providers/ui_provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void onFilePicked(BuildContext context) {
    FilePicker.platform
        .pickFiles(
            type: FileType.custom,
            allowedExtensions: ['json'],
            allowMultiple: false)
        .then((pickerResult) {
      if (pickerResult != null) {
        final file = pickerResult.files.single;
        Provider.of<LanguageProvider>(context, listen: false).languageData =
            Map.from(json.decode(String.fromCharCodes(file.bytes!)));
        Provider.of<UiProvider>(context, listen: false).fileName = file.name;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final UiProvider uiProvider = Provider.of<UiProvider>(context);
    final LanguageProvider languageProvider =
        Provider.of<LanguageProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Translate Generator",
          style: Theme.of(context).textTheme.displayLarge,
        ),
      ),
      body: Center(
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: Colors.white,
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                height: 200,
                width: 200,
                child: !uiProvider.translating
                    ? Image.asset(
                        "assets/images/logo.gif",
                      )
                    : Image.asset("assets/animations/translating.gif"),
              ),
              SizedBox(
                  width: 300,
                  child: LinearPercentIndicator(
                    animateFromLastPercent: true,
                    percent: uiProvider.progress / uiProvider.totalLength,
                    backgroundColor: Colors.grey,
                    progressColor: const Color(0xff5f37da),
                    barRadius: const Radius.circular(20),
                    animation: true,
                  )),
              if (uiProvider.totalLength > 0)
                Text(
                    "${((uiProvider.progress / uiProvider.totalLength) * 100)}%"),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      onFilePicked(context);
                    },
                    child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: const Color(
                                0xff5f37da,
                              ),
                            )),
                        child: Text(
                          uiProvider.fileName ??
                              "Select the file to be translated",
                        )),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        onFilePicked(context);
                      },
                      child: const Text("Choose File")),
                ],
              ),
              const Text(
                "Select the target language",
              ),
              SizedBox(
                height: 50,
                width: 120,
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  dropdownColor: Colors.grey,
                  value: languageProvider.selectedLocale.languageCode,
                  onChanged: (String? newValue) {
                    languageProvider.setLocale = Locale(newValue!);
                  },
                  items: LanguageProvider.supportedLanguages
                      .map<DropdownMenuItem<String>>((Locale value) {
                    return DropdownMenuItem<String>(
                      value: value.languageCode,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            'assets/images/flags/${value.countryCode}.png',
                            height: 30,
                            width: 30,
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Text(value.languageCode),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
              ElevatedButton(
                onPressed: languageProvider.languageData.isEmpty
                    ? null
                    : () {
                        languageProvider.translate();
                      },
                style: languageProvider.languageData.isEmpty
                    ? ElevatedButton.styleFrom(backgroundColor: Colors.grey)
                    : Theme.of(context).elevatedButtonTheme.style,
                child: const Text("Translate"),
              ),
              SizedBox(
                width: 400,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      languageProvider.translatedData.isEmpty
                          ? "Please choose a file to translate"
                          : uiProvider.translating
                              ? "Translating..... please wait"
                              : "Your file is ready for download",
                    ),
                    if (languageProvider.translatedData.isNotEmpty &&
                        !uiProvider.translating)
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: ElevatedButton(
                          onPressed: () {
                            languageProvider.downloadFile();
                          },
                          child: const Text("Download"),
                        ),
                      )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
